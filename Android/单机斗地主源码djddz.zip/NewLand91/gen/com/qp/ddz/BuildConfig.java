/** Automatically generated file. DO NOT MODIFY */
package com.qp.ddz;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}