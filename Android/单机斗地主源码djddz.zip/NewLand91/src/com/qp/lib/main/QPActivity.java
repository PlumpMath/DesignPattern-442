package com.qp.lib.main;

import android.app.Activity;
import android.os.Bundle;

public abstract class QPActivity extends Activity
{

	public QPActivity()
	{
	}

	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
	}
}
