package com.qp.lib.tag;


public class UserScore
{

	public long lScore;
	public long lInsure;
	public long lWinCount;
	public long lLostCount;
	public long lDrawCount;
	public long lFleeCount;
	public long lExperience;

	public UserScore()
	{
	}
}
