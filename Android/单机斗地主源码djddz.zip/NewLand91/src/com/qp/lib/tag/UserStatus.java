package com.qp.lib.tag;


public class UserStatus
{

	public int nTableID;
	public int nChairID;
	public int nStatus;

	public UserStatus()
	{
	}
}
