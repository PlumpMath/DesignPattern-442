package com.qp.lib.tag;


public class GamePropsItem
{

	public int nitemindex;
	public int nresid;
	public String szname;
	public String szDescribe;
	public long lprice;

	public GamePropsItem()
	{
	}
}
