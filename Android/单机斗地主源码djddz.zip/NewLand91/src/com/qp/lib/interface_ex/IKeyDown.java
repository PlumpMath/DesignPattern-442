package com.qp.lib.interface_ex;

import android.view.KeyEvent;

public interface IKeyDown
{

	public abstract boolean _onKeyDown(int i, KeyEvent keyevent);
}
