package com.qp.lib.interface_ex;

public interface INetCommandListener {

	public void onNetCommand(int main, int sub, Object obj);
}
