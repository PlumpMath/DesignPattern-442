package com.qp.lib.control;

import com.qp.lib.interface_ex.bank.IBank;

public abstract class BankControl implements IBank {

	public static int	wRevenueTake;
	public static int	wRevenueTransfer;
	public static long	lUserScore;
	public static long	lUserInsure;
	public static long	lTransferPrerequisite;

}
