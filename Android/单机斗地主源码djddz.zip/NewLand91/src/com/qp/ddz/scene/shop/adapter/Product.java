package com.qp.ddz.scene.shop.adapter;
/**
*
* ��������Դ����ϵ q344717871
* 
*/

public class Product {
	int getCheckSum(){return 0;}
	String getProductName(){return goodsname;}
	String getDesc(){return desc;}	 
	
	public int id;
	public String  goodsname;// char goodsname[32];
	public int goodsprice;
	public String  desc;//char desc[32];
	
}
