package com.qp.ddz.scene.popupwindow.adapter;
/**
*
* ��������Դ����ϵ q344717871
* 
*/

public class ChatInfo {
	public String	name	= "";
	public String	info	= "";

	public ChatInfo() {

	}

	public ChatInfo(String szname, String szinfo) {
		name = szname;
		info = szinfo;
	}
}
