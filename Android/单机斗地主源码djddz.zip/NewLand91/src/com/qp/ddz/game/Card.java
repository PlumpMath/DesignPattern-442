package com.qp.ddz.game;
/*
*
* ��������Դ����ϵ q344717871
* 
* */

public class Card {
	public int		data;
	public boolean	shoot;

	public Card() {
		data = 0;
		shoot = false;
	}

	public void reSet() {
		data = 0;
		shoot = false;
	}
}
