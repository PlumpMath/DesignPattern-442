package com.qp.ddz.utility;
/**
*
* ��������Դ����ϵ q344717871
* 
*/

public class MsgRecordItem {
	public final static int	TYPE_SYS	= 1;
	public final static int	TYPE_HORN	= 2;

	public int				nType		= 0;
	public String			szMsg		= "";
}
