package DesignPattern.state;

/**
 * Created by DrownFish on 2017/4/10.
 */
public interface State {
    public void handle(int money);
}
